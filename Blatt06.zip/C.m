function [v] = C(t)
    v(1) = t*3/4;
    v(2) = (1-t)*3/4;
    v(3) = 1/8;
    v(4) = 1/8;
end

